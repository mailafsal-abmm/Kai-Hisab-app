# Kai Hisab – Android app

A WebView wrapper around the Kai Hisab web app (`app/src/main/assets/index.html`).
All data stays on the phone (browser storage inside the app).

## Build the APK on GitHub (no Android Studio needed)
1. Create a GitHub repository and upload everything in this folder (keep the `.github` folder).
2. Open the repository → **Actions** → **Build Kai Hisab APK** → **Run workflow** (it also runs on every push).
3. When it finishes, open the run and download the **KaiHisab-debug-apk** artifact (a zip containing `app-debug.apk`).
4. Copy the APK to your phone and install it (allow "install unknown apps").

## Build with Android Studio
Open this folder in Android Studio and press Run / Build APK (Gradle 8.7, AGP 8.5.2, JDK 17).

## Updating the app later
Replace `app/src/main/assets/index.html` with the newest `index.html` (and `sw.js` / `manifest.json` if they changed), commit, and run the workflow again. Increase `versionCode` in `app/build.gradle` so the new APK installs over the old one.

## What the wrapper adds
- Share (WhatsApp / Share) of PDF files, PDF / CSV / backup downloads to the Downloads folder, Print, camera and gallery pick for Scan Receipt, and sms: / wa.me links.
- Saved data lives in the app's WebView storage. It is separate from the Chrome PWA, so use **Save Data** in the PWA and **Restore** in the Android app to move your data.

## Note
This project was written without being compiled in the authoring environment. If the GitHub build reports an error, send me the log.
